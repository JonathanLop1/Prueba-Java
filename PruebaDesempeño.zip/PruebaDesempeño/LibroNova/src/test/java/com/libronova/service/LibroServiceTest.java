package com.libronova.service;

import com.libronova.exception.ValidationException;
import com.libronova.model.Libro;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.time.LocalDateTime;

public class LibroServiceTest {

    private LibroService service;

    @BeforeEach
    void setUp() {
        service = new LibroService();
    }

    @Test
void testAgregarLibro_DuplicadoISBN() {
    assertThrows(ValidationException.class, () -> {
        // Simulamos dos libros con mismo ISBN sin tocar la BD
        LibroService service = new LibroService();
        Libro libro = new Libro("X123", "Mock Book", "Author", "Fiction", 5, 5, 10000.0, true, LocalDateTime.now());
        service.agregarLibro(libro);
        service.agregarLibro(libro); // Segunda vez: debería lanzar excepción
    });
}


    @Test
    void testActualizarLibro_StockInvalido() {
        Libro libro = new Libro("456", "Test 2", "Author", "Drama", 5, 10, 10000.0, true, LocalDateTime.now());
        assertThrows(ValidationException.class, () -> service.actualizarLibro(libro),
                "No debe permitir que ejemplares disponibles superen los totales");
    }
}
