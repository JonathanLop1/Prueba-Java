package com.libronova.service;

import com.libronova.exception.BusinessException;
import com.libronova.model.Libro;
import com.libronova.model.Prestamo;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDate;

import static org.junit.jupiter.api.Assertions.*;

public class PrestamoServiceTest {

    private PrestamoService prestamoService;
    private LibroService libroService;

    @BeforeEach
    void setup() {
        prestamoService = new PrestamoService();
        libroService = new LibroService();
    }

    @Test
    void testRegistrarPrestamo_SinStock() {
        Prestamo p = new Prestamo(0, "1", "noexistente", LocalDate.now(), LocalDate.now().plusDays(7), false, 0);
        BusinessException ex = assertThrows(BusinessException.class,
                () -> prestamoService.registrarPrestamo(p),
                "Debe lanzar excepción si el libro no tiene stock disponible o no existe");
        assertTrue(ex.getMessage().contains("libro"));
    }
}
