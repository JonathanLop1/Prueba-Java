package com.libronova.validation;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.time.LocalDate;

public class ValidatorsTest {

    @Test
    void testCalcularMulta_SinRetraso() {
        double multa = Validators.calcularMulta(LocalDate.of(2025, 10, 10), LocalDate.of(2025, 10, 15));
        assertEquals(0, multa, "No debe haber multa si la devolución está dentro del plazo");
    }

    @Test
    void testCalcularMulta_ConRetraso() {
        double multa = Validators.calcularMulta(LocalDate.of(2025, 10, 20), LocalDate.of(2025, 10, 15));
        assertTrue(multa > 0, "Debe calcular una multa si hay retraso");
    }
}
