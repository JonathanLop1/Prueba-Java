-- =====================================
-- 📘 Base de datos LibroNova (MySQL)
-- =====================================

-- Crear base de datos
DROP DATABASE IF EXISTS libronova;
CREATE DATABASE libronova CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE libronova;

-- ======================
-- Tabla: usuarios
-- ======================
CREATE TABLE usuarios (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(100) NOT NULL,
    rol ENUM('ADMIN', 'ASISTENTE') NOT NULL DEFAULT 'ASISTENTE',
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ======================
-- Tabla: socios
-- ======================
CREATE TABLE socios (
    id VARCHAR(20) PRIMARY KEY,
    nombre VARCHAR(100) NOT NULL,
    email VARCHAR(100),
    telefono VARCHAR(20),
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ======================
-- Tabla: libros
-- ======================
CREATE TABLE libros (
    isbn VARCHAR(20) PRIMARY KEY,
    titulo VARCHAR(200) NOT NULL,
    autor VARCHAR(100) NOT NULL,
    categoria VARCHAR(100),
    ejemplares_totales INT NOT NULL,
    ejemplares_disponibles INT NOT NULL,
    precio_referencia DECIMAL(10,2) NOT NULL,
    activo BOOLEAN NOT NULL DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ======================
-- Tabla: prestamos
-- ======================
CREATE TABLE prestamos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    id_socio VARCHAR(20) NOT NULL,
    isbn_libro VARCHAR(20) NOT NULL,
    fecha_prestamo DATE NOT NULL,
    fecha_devolucion DATE NOT NULL,
    devuelto BOOLEAN DEFAULT FALSE,
    multa DECIMAL(10,2) DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (id_socio) REFERENCES socios(id) ON UPDATE CASCADE ON DELETE RESTRICT,
    FOREIGN KEY (isbn_libro) REFERENCES libros(isbn) ON UPDATE CASCADE ON DELETE RESTRICT
);

-- ======================
-- Índices adicionales
-- ======================
CREATE INDEX idx_prestamos_socio ON prestamos(id_socio);
CREATE INDEX idx_prestamos_libro ON prestamos(isbn_libro);

-- ======================
-- Usuario admin por defecto
-- ======================
INSERT INTO usuarios (username, password, rol, activo)
VALUES ('admin', 'admin123', 'ADMIN', TRUE);
