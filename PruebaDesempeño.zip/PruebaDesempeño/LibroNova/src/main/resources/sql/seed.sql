USE libronova;

-- ======================
-- Insertar socios
-- ======================
INSERT INTO socios (id, nombre, email, telefono, activo) VALUES
('CC1001', 'Laura Gómez', 'laura@example.com', '3112233445', TRUE),
('CC1002', 'Carlos Pérez', 'carlos@example.com', '3205566778', TRUE),
('CC1003', 'Ana Torres', 'ana@example.com', '3109988776', FALSE);

-- ======================
-- Insertar libros
-- ======================
INSERT INTO libros (isbn, titulo, autor, categoria, ejemplares_totales, ejemplares_disponibles, precio_referencia, activo) VALUES
('9781234567890', 'El Principito', 'Antoine de Saint-Exupéry', 'Ficción', 10, 8, 25000, TRUE),
('9789876543210', 'Java Básico', 'James Gosling', 'Programación', 5, 5, 40000, TRUE),
('9781111111111', 'Cien Años de Soledad', 'Gabriel García Márquez', 'Novela', 7, 6, 35000, TRUE),
('9782222222222', 'Don Quijote de la Mancha', 'Miguel de Cervantes', 'Clásico', 4, 3, 30000, TRUE);

-- ======================
-- Insertar préstamos
-- ======================
INSERT INTO prestamos (id_socio, isbn_libro, fecha_prestamo, fecha_devolucion, devuelto, multa) VALUES
('CC1001', '9781234567890', '2025-10-01', '2025-10-08', FALSE, 0),
('CC1002', '9789876543210', '2025-09-25', '2025-10-02', TRUE, 1500);
