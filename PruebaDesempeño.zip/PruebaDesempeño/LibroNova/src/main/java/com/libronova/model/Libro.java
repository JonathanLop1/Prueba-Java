package com.libronova.model;

import java.time.LocalDateTime;

/**
 * Representa un libro dentro del catálogo de LibroNova.
 * Cumple con las reglas de negocio: ISBN único, control de stock, y estado activo/inactivo.
 */
public class Libro {
    private String isbn;
    private String titulo;
    private String autor;
    private String categoria;
    private int ejemplaresTotales;
    private int ejemplaresDisponibles;
    private double precioReferencia;
    private boolean activo;
    private LocalDateTime createdAt;

    public Libro() {}

    public Libro(String isbn, String titulo, String autor, String categoria,
                 int ejemplaresTotales, int ejemplaresDisponibles,
                 double precioReferencia, boolean activo, LocalDateTime createdAt) {
        this.isbn = isbn;
        this.titulo = titulo;
        this.autor = autor;
        this.categoria = categoria;
        this.ejemplaresTotales = ejemplaresTotales;
        this.ejemplaresDisponibles = ejemplaresDisponibles;
        this.precioReferencia = precioReferencia;
        this.activo = activo;
        this.createdAt = createdAt;
    }

    // Getters y Setters
    public String getIsbn() { return isbn; }
    public void setIsbn(String isbn) { this.isbn = isbn; }

    public String getTitulo() { return titulo; }
    public void setTitulo(String titulo) { this.titulo = titulo; }

    public String getAutor() { return autor; }
    public void setAutor(String autor) { this.autor = autor; }

    public String getCategoria() { return categoria; }
    public void setCategoria(String categoria) { this.categoria = categoria; }

    public int getEjemplaresTotales() { return ejemplaresTotales; }
    public void setEjemplaresTotales(int ejemplaresTotales) { this.ejemplaresTotales = ejemplaresTotales; }

    public int getEjemplaresDisponibles() { return ejemplaresDisponibles; }
    public void setEjemplaresDisponibles(int ejemplaresDisponibles) { this.ejemplaresDisponibles = ejemplaresDisponibles; }

    public double getPrecioReferencia() { return precioReferencia; }
    public void setPrecioReferencia(double precioReferencia) { this.precioReferencia = precioReferencia; }

    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    @Override
    public String toString() {
        return String.format("%s - %s (%s) [%s] [%s]",
                isbn, titulo, autor,
                categoria, activo ? "ACTIVO" : "INACTIVO");
    }
}
