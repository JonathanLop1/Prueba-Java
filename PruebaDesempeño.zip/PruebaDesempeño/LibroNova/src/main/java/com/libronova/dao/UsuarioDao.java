package com.libronova.dao;

import com.libronova.model.Usuario;
import java.util.List;

public interface UsuarioDao {
    void crear(Usuario usuario);
    void actualizar(Usuario usuario);
    void eliminar(String username);
    Usuario buscarPorUsername(String username);
    List<Usuario> listar();
}
