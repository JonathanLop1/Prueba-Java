package com.libronova.util;

import java.io.IOException;
import java.util.logging.*;

public class LogConfig {

    private static boolean initialized = false;

    public static Logger getLogger(Class<?> clazz) {
        if (!initialized) {
            try {
                LogManager.getLogManager().reset();
                Logger rootLogger = Logger.getLogger("");
                FileHandler fileHandler = new FileHandler("app.log", true);
                fileHandler.setFormatter(new SimpleFormatter());
                rootLogger.addHandler(fileHandler);
                rootLogger.setLevel(Level.INFO);
                initialized = true;
            } catch (IOException e) {
                System.err.println("Error inicializando logs: " + e.getMessage());
            }
        }
        return Logger.getLogger(clazz.getName());
    }
}
