package com.libronova.decorator;

import com.libronova.dao.UsuarioDao;
import com.libronova.model.Usuario;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Decorador para aplicar propiedades por defecto al crear usuarios.
 * Cumple el requisito del enunciado: aplicar un decorador sin modificar la lógica base.
 */
public class UsuarioDecorator implements UsuarioDao {

    private final UsuarioDao usuarioDao;

    public UsuarioDecorator(UsuarioDao usuarioDao) {
        this.usuarioDao = usuarioDao;
    }

    @Override
    public void crear(Usuario usuario) {
        if (usuario.getRol() == null || usuario.getRol().isBlank()) {
            usuario.setRol("ASISTENTE");
        }
        usuario.setActivo(true);
        if (usuario.getCreatedAt() == null) {
            usuario.setCreatedAt(LocalDateTime.now());
        }
        System.out.println("[POST] /usuarios → creando usuario '" + usuario.getUsername() + "' con rol " + usuario.getRol());
        usuarioDao.crear(usuario);
    }

    @Override
    public void actualizar(Usuario usuario) {
        System.out.println("[PATCH] /usuarios/" + usuario.getUsername());
        usuarioDao.actualizar(usuario);
    }

    @Override
    public void eliminar(String username) {
        System.out.println("[DELETE] /usuarios/" + username);
        usuarioDao.eliminar(username);
    }

    @Override
    public Usuario buscarPorUsername(String username) {
        System.out.println("[GET] /usuarios/" + username);
        return usuarioDao.buscarPorUsername(username);
    }

    @Override
    public List<Usuario> listar() {
        System.out.println("[GET] /usuarios");
        return usuarioDao.listar();
    }
}
