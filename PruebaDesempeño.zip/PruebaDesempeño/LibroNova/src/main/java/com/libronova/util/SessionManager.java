package com.libronova.util;

import com.libronova.model.Usuario;

/**
 * Clase para manejar la sesión del usuario autenticado en la aplicación.
 */
public class SessionManager {

    private static Usuario usuarioActual;

    private SessionManager() {}

    public static void iniciarSesion(Usuario usuario) {
        usuarioActual = usuario;
    }

    public static Usuario getUsuarioActual() {
        return usuarioActual;
    }

    public static boolean haySesionActiva() {
        return usuarioActual != null;
    }

    public static void cerrarSesion() {
        usuarioActual = null;
    }
}
