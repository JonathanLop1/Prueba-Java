package com.libronova.dao;

import com.libronova.model.Socio;
import java.util.List;

public interface SocioDao {
    void crear(Socio socio);
    void actualizar(Socio socio);
    void eliminar(String id);
    List<Socio> listar();

    public Socio buscarPorId(String idSocio);
}
