package com.libronova.model;

import java.time.LocalDate;

public class Prestamo {
    private int id;
    private String idSocio;
    private String isbnLibro;
    private LocalDate fechaPrestamo;
    private LocalDate fechaDevolucion;
    private boolean devuelto;
    private double multa;

    // campos adicionales para mostrar
    private String nombreSocio;
    private String tituloLibro;

    public Prestamo(int id, String idSocio, String isbnLibro, LocalDate fechaPrestamo, LocalDate fechaDevolucion, boolean devuelto, double multa) {
        this.id = id;
        this.idSocio = idSocio;
        this.isbnLibro = isbnLibro;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucion = fechaDevolucion;
        this.devuelto = devuelto;
        this.multa = multa;
    }

    // getters y setters
    public int getId() { return id; }
    public String getIdSocio() { return idSocio; }
    public String getIsbnLibro() { return isbnLibro; }
    public LocalDate getFechaPrestamo() { return fechaPrestamo; }
    public LocalDate getFechaDevolucion() { return fechaDevolucion; }
    public boolean isDevuelto() { return devuelto; }
    public double getMulta() { return multa; }

    public void setDevuelto(boolean devuelto) { this.devuelto = devuelto; }
    public void setMulta(double multa) { this.multa = multa; }
    public void setNombreSocio(String nombreSocio) { this.nombreSocio = nombreSocio; }
    public void setTituloLibro(String tituloLibro) { this.tituloLibro = tituloLibro; }

    public String getNombreSocio() { return nombreSocio; }
    public String getTituloLibro() { return tituloLibro; }

    @Override
    public String toString() {
        return tituloLibro + " (" + nombreSocio + ")";
    }
}
