package com.libronova.controller;

import com.libronova.model.Libro;
import com.libronova.model.Prestamo;
import com.libronova.model.Socio;
import com.libronova.service.LibroService;
import com.libronova.service.PrestamoService;
import com.libronova.service.SocioService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDate;

public class PrestamoController {

    @FXML private ComboBox<Socio> cmbSocio;
    @FXML private ComboBox<Libro> cmbLibro;
    @FXML private DatePicker dpFechaDevolucion;
    @FXML private TableView<Prestamo> tablaPrestamos;

    @FXML private TableColumn<Prestamo, Integer> colId;
    @FXML private TableColumn<Prestamo, String> colSocio;
    @FXML private TableColumn<Prestamo, String> colLibro;
    @FXML private TableColumn<Prestamo, LocalDate> colFechaPrestamo;
    @FXML private TableColumn<Prestamo, LocalDate> colFechaDevolucion;
    @FXML private TableColumn<Prestamo, Boolean> colDevuelto;
    @FXML private TableColumn<Prestamo, Double> colMulta;

    private final PrestamoService prestamoService = new PrestamoService();
    private final SocioService socioService = new SocioService();
    private final LibroService libroService = new LibroService();

    private final ObservableList<Prestamo> prestamos = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(data -> new javafx.beans.property.SimpleIntegerProperty(data.getValue().getId()).asObject());
        colSocio.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getNombreSocio()));
        colLibro.setCellValueFactory(data -> new javafx.beans.property.SimpleStringProperty(data.getValue().getTituloLibro()));
        colFechaPrestamo.setCellValueFactory(data -> new javafx.beans.property.SimpleObjectProperty<>(data.getValue().getFechaPrestamo()));
        colFechaDevolucion.setCellValueFactory(data -> new javafx.beans.property.SimpleObjectProperty<>(data.getValue().getFechaDevolucion()));
        colDevuelto.setCellValueFactory(data -> new javafx.beans.property.SimpleBooleanProperty(data.getValue().isDevuelto()).asObject());
        colMulta.setCellValueFactory(data -> new javafx.beans.property.SimpleDoubleProperty(data.getValue().getMulta()).asObject());

        cmbSocio.setItems(FXCollections.observableArrayList(socioService.listarSocios()));
        cmbLibro.setItems(FXCollections.observableArrayList(libroService.listarLibros()));

        refrescarTabla();
    }

    @FXML
    private void registrarPrestamo() {
        try {
            Socio socio = cmbSocio.getValue();
            Libro libro = cmbLibro.getValue();
            LocalDate fechaDevolucion = dpFechaDevolucion.getValue();

            if (socio == null || libro == null || fechaDevolucion == null) {
                alert("Campos incompletos", "Seleccione socio, libro y fecha de devolución.", Alert.AlertType.WARNING);
                return;
            }

            Prestamo p = new Prestamo(0, socio.getId(), libro.getIsbn(),
                    LocalDate.now(), fechaDevolucion, false, 0);
            prestamoService.registrarPrestamo(p);
            alert("Éxito", "Préstamo registrado correctamente.", Alert.AlertType.INFORMATION);
            refrescarTabla();

        } catch (Exception e) {
            alert("Error", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void devolverLibro() {
        Prestamo p = tablaPrestamos.getSelectionModel().getSelectedItem();
        if (p == null) {
            alert("Seleccione un préstamo", "Debe seleccionar un registro para devolver.", Alert.AlertType.WARNING);
            return;
        }
        try {
            prestamoService.devolverLibro(p.getIdSocio(), p.getIsbnLibro());
            alert("Éxito", "Libro devuelto correctamente.", Alert.AlertType.INFORMATION);
            refrescarTabla();
        } catch (Exception e) {
            alert("Error", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void exportarPrestamos() {
        prestamoService.exportarPrestamosCSV();
        alert("Exportación completa", "Préstamos exportados correctamente.", Alert.AlertType.INFORMATION);
    }

    @FXML
    private void exportarPrestamosVencidos() {
        prestamoService.exportarPrestamosVencidosCSV();
        alert("Exportación completa", "Préstamos vencidos exportados correctamente.", Alert.AlertType.INFORMATION);
    }

    private void refrescarTabla() {
        prestamos.setAll(prestamoService.listarPrestamos());
        tablaPrestamos.setItems(prestamos);
    }

    @FXML
    private void regresarMenu() throws IOException {
        Stage stage = (Stage) tablaPrestamos.getScene().getWindow();
        Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/view/main.fxml")));
        stage.setScene(scene);
    }

    private void alert(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }
}
