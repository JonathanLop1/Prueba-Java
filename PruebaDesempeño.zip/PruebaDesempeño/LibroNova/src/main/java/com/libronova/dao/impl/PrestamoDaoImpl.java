package com.libronova.dao.impl;

import com.libronova.dao.PrestamoDao;
import com.libronova.model.Prestamo;
import com.libronova.util.DB;

import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementación JDBC de PrestamoDao para MySQL.
 * Maneja inserciones, actualizaciones, consultas y listados
 * incluyendo préstamos vencidos y activos.
 */
public class PrestamoDaoImpl implements PrestamoDao {

    @Override
    public void crear(Prestamo p) {
        String insert = "INSERT INTO prestamos (id_socio, isbn_libro, fecha_prestamo, fecha_devolucion, devuelto, multa) VALUES (?, ?, ?, ?, ?, ?)";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(insert)) {
            ps.setString(1, p.getIdSocio());
            ps.setString(2, p.getIsbnLibro());
            ps.setDate(3, Date.valueOf(p.getFechaPrestamo()));
            ps.setDate(4, Date.valueOf(p.getFechaDevolucion()));
            ps.setBoolean(5, p.isDevuelto());
            ps.setDouble(6, p.getMulta());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al registrar préstamo: " + e.getMessage(), e);
        }
    }

    @Override
    public void actualizar(Prestamo p) {
        String sql = "UPDATE prestamos SET devuelto=?, multa=? WHERE id=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setBoolean(1, p.isDevuelto());
            ps.setDouble(2, p.getMulta());
            ps.setInt(3, p.getId());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar préstamo: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Prestamo> listar() {
        List<Prestamo> lista = new ArrayList<>();
        String sql = """
            SELECT p.*, s.nombre AS nombre_socio, l.titulo AS titulo_libro
            FROM prestamos p
            JOIN socios s ON p.id_socio = s.id
            JOIN libros l ON p.isbn_libro = l.isbn
            ORDER BY p.created_at DESC
            """;
        try (Connection con = DB.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Prestamo p = map(rs);
                p.setNombreSocio(rs.getString("nombre_socio"));
                p.setTituloLibro(rs.getString("titulo_libro"));
                lista.add(p);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al listar préstamos: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public List<Prestamo> listarVencidos() {
        List<Prestamo> lista = new ArrayList<>();
        String sql = """
            SELECT p.*, s.nombre AS nombre_socio, l.titulo AS titulo_libro
            FROM prestamos p
            JOIN socios s ON p.id_socio = s.id
            JOIN libros l ON p.isbn_libro = l.isbn
            WHERE p.devuelto = false AND p.fecha_devolucion < CURDATE()
            ORDER BY p.fecha_devolucion ASC
            """;
        try (Connection con = DB.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Prestamo p = map(rs);
                p.setNombreSocio(rs.getString("nombre_socio"));
                p.setTituloLibro(rs.getString("titulo_libro"));
                lista.add(p);
            }

        } catch (SQLException e) {
            throw new RuntimeException("Error al listar préstamos vencidos: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public Prestamo buscarPrestamoPendiente(String idSocio, String isbn) {
        String sql = "SELECT * FROM prestamos WHERE id_socio=? AND isbn_libro=? AND devuelto=false";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, idSocio);
            ps.setString(2, isbn);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return map(rs);
            }
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar préstamo pendiente: " + e.getMessage(), e);
        }
        return null;
    }

    /**
     * Mapea un ResultSet a un objeto Prestamo.
     */
    private Prestamo map(ResultSet rs) throws SQLException {
        return new Prestamo(
                rs.getInt("id"),
                rs.getString("id_socio"),
                rs.getString("isbn_libro"),
                rs.getDate("fecha_prestamo").toLocalDate(),
                rs.getDate("fecha_devolucion").toLocalDate(),
                rs.getBoolean("devuelto"),
                rs.getDouble("multa")
        );
    }
}
