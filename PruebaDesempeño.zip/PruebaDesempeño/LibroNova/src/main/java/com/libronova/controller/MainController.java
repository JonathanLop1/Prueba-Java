package com.libronova.controller;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import java.io.IOException;

public class MainController {

    @FXML
    private void abrirLibros() throws IOException {
        cambiarVista("/view/libro.fxml");
    }

    @FXML
    private void abrirUsuarios() throws IOException {
        cambiarVista("/view/usuario.fxml");
    }

    @FXML
    private void abrirSocios() throws IOException {
        cambiarVista("/view/socio.fxml");
    }

    @FXML
    private void abrirPrestamos() throws IOException {
        cambiarVista("/view/prestamo.fxml");
    }

    @FXML
    private void cerrarSesion() throws IOException {
        cambiarVista("/view/login.fxml");
    }

    private void cambiarVista(String fxmlPath) throws IOException {
        // Busca la ventana activa (Stage)
        Stage stage = (Stage) Stage.getWindows().stream()
                .filter(window -> window.isShowing())
                .findFirst()
                .orElseThrow(() -> new IOException("No hay ventana activa"));

        // Carga el nuevo FXML
        Scene scene = new Scene(FXMLLoader.load(getClass().getResource(fxmlPath)));
        stage.setScene(scene);
        stage.show();
    }
}
