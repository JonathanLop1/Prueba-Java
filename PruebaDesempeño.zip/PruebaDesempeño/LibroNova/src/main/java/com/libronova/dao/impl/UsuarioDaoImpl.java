package com.libronova.dao.impl;

import com.libronova.dao.UsuarioDao;
import com.libronova.model.Usuario;
import com.libronova.util.DB;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class UsuarioDaoImpl implements UsuarioDao {

    @Override
    public void crear(Usuario usuario) {
        String sql = "INSERT INTO usuarios (username, password, rol, activo, created_at) VALUES (?, ?, ?, ?, NOW())";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, usuario.getUsername());
            ps.setString(2, usuario.getPassword());
            ps.setString(3, usuario.getRol());
            ps.setBoolean(4, usuario.isActivo());
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("Error al crear usuario: " + e.getMessage()); }
    }

    @Override
    public void actualizar(Usuario usuario) {
        String sql = "UPDATE usuarios SET password=?, rol=?, activo=? WHERE username=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, usuario.getPassword());
            ps.setString(2, usuario.getRol());
            ps.setBoolean(3, usuario.isActivo());
            ps.setString(4, usuario.getUsername());
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("Error al actualizar usuario: " + e.getMessage()); }
    }

    @Override
    public void eliminar(String username) {
        String sql = "DELETE FROM usuarios WHERE username=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ps.executeUpdate();
        } catch (SQLException e) { throw new RuntimeException("Error al eliminar usuario: " + e.getMessage()); }
    }

    @Override
    public Usuario buscarPorUsername(String username) {
        String sql = "SELECT * FROM usuarios WHERE username=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                return new Usuario(
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("rol"),
                        rs.getBoolean("activo"),
                        rs.getTimestamp("created_at").toLocalDateTime());
            }
        } catch (SQLException e) { throw new RuntimeException("Error al buscar usuario: " + e.getMessage()); }
        return null;
    }

    @Override
    public List<Usuario> listar() {
        List<Usuario> lista = new ArrayList<>();
        String sql = "SELECT * FROM usuarios";
        try (Connection con = DB.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) {
                lista.add(new Usuario(
                        rs.getString("username"),
                        rs.getString("password"),
                        rs.getString("rol"),
                        rs.getBoolean("activo"),
                        rs.getTimestamp("created_at").toLocalDateTime()));
            }
        } catch (SQLException e) { throw new RuntimeException("Error al listar usuarios: " + e.getMessage()); }
        return lista;
    }
}
