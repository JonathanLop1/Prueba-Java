package com.libronova.controller;

import com.libronova.model.Libro;
import com.libronova.service.LibroService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDateTime;

public class LibroController {

    @FXML private TextField txtIsbn, txtTitulo, txtAutor, txtCategoria, txtEjemplares, txtPrecio;
    @FXML private TableView<Libro> tablaLibros;

    @FXML private TableColumn<Libro, String> colIsbn;
    @FXML private TableColumn<Libro, String> colTitulo;
    @FXML private TableColumn<Libro, String> colAutor;
    @FXML private TableColumn<Libro, String> colCategoria;
    @FXML private TableColumn<Libro, Integer> colTotales;
    @FXML private TableColumn<Libro, Integer> colDisponibles;
    @FXML private TableColumn<Libro, Double> colPrecio;

    private final LibroService libroService = new LibroService();
    private final ObservableList<Libro> libros = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colIsbn.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue().getIsbn()));
        colTitulo.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue().getTitulo()));
        colAutor.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue().getAutor()));
        colCategoria.setCellValueFactory(d -> new javafx.beans.property.SimpleStringProperty(d.getValue().getCategoria()));
        colTotales.setCellValueFactory(d -> new javafx.beans.property.SimpleIntegerProperty(d.getValue().getEjemplaresTotales()).asObject());
        colDisponibles.setCellValueFactory(d -> new javafx.beans.property.SimpleIntegerProperty(d.getValue().getEjemplaresDisponibles()).asObject());
        colPrecio.setCellValueFactory(d -> new javafx.beans.property.SimpleDoubleProperty(d.getValue().getPrecioReferencia()).asObject());

        tablaLibros.setItems(libros);
        refrescar();

        tablaLibros.setOnMouseClicked(event -> {
            Libro l = tablaLibros.getSelectionModel().getSelectedItem();
            if (l != null) {
                txtIsbn.setText(l.getIsbn());
                txtTitulo.setText(l.getTitulo());
                txtAutor.setText(l.getAutor());
                txtCategoria.setText(l.getCategoria());
                txtEjemplares.setText(String.valueOf(l.getEjemplaresTotales()));
                txtPrecio.setText(String.valueOf(l.getPrecioReferencia()));
            }
        });
    }

    @FXML
    private void agregarLibro() {
        try {
            Libro l = new Libro(
                    txtIsbn.getText(),
                    txtTitulo.getText(),
                    txtAutor.getText(),
                    txtCategoria.getText(),
                    Integer.parseInt(txtEjemplares.getText()),
                    Integer.parseInt(txtEjemplares.getText()),
                    Double.parseDouble(txtPrecio.getText()),
                    true,
                    LocalDateTime.now()
            );
            libroService.agregarLibro(l);
            alert("Éxito", "Libro agregado correctamente.", Alert.AlertType.INFORMATION);
            refrescar();
            limpiarCampos();
        } catch (Exception e) {
            alert("Error", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void editarLibro() {
        try {
            Libro l = tablaLibros.getSelectionModel().getSelectedItem();
            if (l == null) {
                alert("Seleccione un libro", "Debe seleccionar un registro para editar.", Alert.AlertType.WARNING);
                return;
            }
            l.setTitulo(txtTitulo.getText());
            l.setAutor(txtAutor.getText());
            l.setCategoria(txtCategoria.getText());
            l.setEjemplaresTotales(Integer.parseInt(txtEjemplares.getText()));
            l.setPrecioReferencia(Double.parseDouble(txtPrecio.getText()));

            libroService.actualizarLibro(l);
            alert("Actualizado", "Libro actualizado correctamente.", Alert.AlertType.INFORMATION);
            refrescar();
        } catch (Exception e) {
            alert("Error", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void eliminarLibro() {
        Libro l = tablaLibros.getSelectionModel().getSelectedItem();
        if (l == null) {
            alert("Seleccione un libro", "Debe seleccionar un registro para eliminar.", Alert.AlertType.WARNING);
            return;
        }
        Alert confirm = new Alert(Alert.AlertType.CONFIRMATION, "¿Eliminar libro seleccionado?", ButtonType.YES, ButtonType.NO);
        confirm.showAndWait().ifPresent(b -> {
            if (b == ButtonType.YES) {
                libroService.eliminarLibro(l.getIsbn());
                refrescar();
            }
        });
    }

    @FXML
    private void exportarLibros() {
        libroService.exportarCatalogo();
        alert("Exportación completa", "Libros exportados correctamente.", Alert.AlertType.INFORMATION);
    }

    @FXML
    private void regresarMenu() throws IOException {
        Stage stage = (Stage) tablaLibros.getScene().getWindow();
        Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/view/main.fxml")));
        stage.setScene(scene);
    }

    private void refrescar() {
        libros.setAll(libroService.listarLibros());
    }

    private void limpiarCampos() {
        txtIsbn.clear();
        txtTitulo.clear();
        txtAutor.clear();
        txtCategoria.clear();
        txtEjemplares.clear();
        txtPrecio.clear();
    }

    private void alert(String t, String m, Alert.AlertType tp) {
        Alert a = new Alert(tp);
        a.setTitle(t);
        a.setHeaderText(null);
        a.setContentText(m);
        a.showAndWait();
    }
}
