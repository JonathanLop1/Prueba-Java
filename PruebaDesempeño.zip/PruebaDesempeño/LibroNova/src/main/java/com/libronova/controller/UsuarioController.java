package com.libronova.controller;

import com.libronova.model.Usuario;
import com.libronova.service.UsuarioService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;

import java.io.IOException;

public class UsuarioController {

    @FXML private TextField txtUsername;
    @FXML private PasswordField txtPassword;
    @FXML private ComboBox<String> cmbRol;
    @FXML private TableView<Usuario> tablaUsuarios;
    @FXML private TableColumn<Usuario, String> colUsername;
    @FXML private TableColumn<Usuario, String> colRol;
    @FXML private TableColumn<Usuario, Boolean> colActivo;
    @FXML private TableColumn<Usuario, String> colCreatedAt;

    private final UsuarioService usuarioService = new UsuarioService();
    private final ObservableList<Usuario> usuarios = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        // Configurar columnas
        colUsername.setCellValueFactory(new PropertyValueFactory<>("username"));
        colRol.setCellValueFactory(new PropertyValueFactory<>("rol"));
        colActivo.setCellValueFactory(new PropertyValueFactory<>("activo"));
        colCreatedAt.setCellValueFactory(new PropertyValueFactory<>("createdAt"));

        // Configurar roles en ComboBox
        cmbRol.setItems(FXCollections.observableArrayList("ADMIN", "ASISTENTE"));

        // Cargar usuarios
        refrescarTabla();
    }

    @FXML
    private void crearUsuario() {
        try {
            String username = txtUsername.getText().trim();
            String password = txtPassword.getText().trim();
            String rol = cmbRol.getValue();

            if (username.isEmpty() || password.isEmpty() || rol == null) {
                alert("Error", "Todos los campos son obligatorios.", Alert.AlertType.ERROR);
                return;
            }

            Usuario u = new Usuario(username, password, rol, true, java.time.LocalDateTime.now());
            usuarioService.crearUsuario(u);
            alert("Éxito", "Usuario creado correctamente.", Alert.AlertType.INFORMATION);
            refrescarTabla();
            limpiarCampos();

        } catch (Exception e) {
            alert("Error", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void eliminarUsuario() {
        Usuario seleccionado = tablaUsuarios.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            alert("Error", "Seleccione un usuario para eliminar.", Alert.AlertType.WARNING);
            return;
        }

        try {
            usuarioService.eliminarUsuario(seleccionado.getUsername());
            alert("Eliminado", "Usuario eliminado correctamente.", Alert.AlertType.INFORMATION);
            refrescarTabla();
        } catch (Exception e) {
            alert("Error", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void exportarUsuarios() {
        try {
            usuarioService.exportarUsuarios();
            alert("Éxito", "Usuarios exportados correctamente.", Alert.AlertType.INFORMATION);
        } catch (Exception e) {
            alert("Error", "No se pudo exportar: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    private void regresarMenu() {
        try {
            Stage stage = (Stage) tablaUsuarios.getScene().getWindow();
            Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/view/main.fxml")));
            stage.setScene(scene);
        } catch (IOException e) {
            alert("Error", "No se pudo regresar al menú: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void refrescarTabla() {
        usuarios.setAll(usuarioService.listarUsuarios());
        tablaUsuarios.setItems(usuarios);
    }

    private void limpiarCampos() {
        txtUsername.clear();
        txtPassword.clear();
        cmbRol.setValue(null);
    }

    private void alert(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert a = new Alert(tipo);
        a.setTitle(titulo);
        a.setHeaderText(null);
        a.setContentText(mensaje);
        a.showAndWait();
    }
}
