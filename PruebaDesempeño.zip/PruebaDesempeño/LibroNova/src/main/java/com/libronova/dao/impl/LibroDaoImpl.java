package com.libronova.dao.impl;

import com.libronova.dao.LibroDao;
import com.libronova.model.Libro;
import com.libronova.util.DB;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class LibroDaoImpl implements LibroDao {

    @Override
    public void crear(Libro libro) {
        String sql = "INSERT INTO libros (isbn, titulo, autor, categoria, ejemplares_totales, ejemplares_disponibles, precio_referencia, activo, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, libro.getIsbn());
            ps.setString(2, libro.getTitulo());
            ps.setString(3, libro.getAutor());
            ps.setString(4, libro.getCategoria());
            ps.setInt(5, libro.getEjemplaresTotales());
            ps.setInt(6, libro.getEjemplaresDisponibles());
            ps.setDouble(7, libro.getPrecioReferencia());
            ps.setBoolean(8, libro.isActivo());
            ps.setTimestamp(9, Timestamp.valueOf(libro.getCreatedAt()));
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al crear libro: " + e.getMessage(), e);
        }
    }

    @Override
    public void actualizar(Libro libro) {
        String sql = "UPDATE libros SET titulo=?, autor=?, categoria=?, ejemplares_totales=?, ejemplares_disponibles=?, precio_referencia=?, activo=? WHERE isbn=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, libro.getTitulo());
            ps.setString(2, libro.getAutor());
            ps.setString(3, libro.getCategoria());
            ps.setInt(4, libro.getEjemplaresTotales());
            ps.setInt(5, libro.getEjemplaresDisponibles());
            ps.setDouble(6, libro.getPrecioReferencia());
            ps.setBoolean(7, libro.isActivo());
            ps.setString(8, libro.getIsbn());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al actualizar libro: " + e.getMessage(), e);
        }
    }

    @Override
    public void eliminar(String isbn) {
        String sql = "DELETE FROM libros WHERE isbn=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, isbn);
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException("Error al eliminar libro: " + e.getMessage(), e);
        }
    }


    @Override
    public Libro buscarPorIsbn(String isbn) {
        String sql = "SELECT * FROM libros WHERE isbn=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, isbn);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        } catch (SQLException e) {
            throw new RuntimeException("Error al buscar libro: " + e.getMessage(), e);
        }
        return null;
    }

    @Override
    public List<Libro> listar() {
        List<Libro> lista = new ArrayList<>();
        String sql = "SELECT * FROM libros";
        try (Connection con = DB.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {
            while (rs.next()) lista.add(map(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error al listar libros: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public List<Libro> filtrarPorAutorOCategoria(String criterio) {
        List<Libro> lista = new ArrayList<>();
        String sql = "SELECT * FROM libros WHERE autor LIKE ? OR categoria LIKE ?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, "%" + criterio + "%");
            ps.setString(2, "%" + criterio + "%");
            ResultSet rs = ps.executeQuery();
            while (rs.next()) lista.add(map(rs));
        } catch (SQLException e) {
            throw new RuntimeException("Error al filtrar libros: " + e.getMessage(), e);
        }
        return lista;
    }

    private Libro map(ResultSet rs) throws SQLException {
        return new Libro(
                rs.getString("isbn"),
                rs.getString("titulo"),
                rs.getString("autor"),
                rs.getString("categoria"),
                rs.getInt("ejemplares_totales"),
                rs.getInt("ejemplares_disponibles"),
                rs.getDouble("precio_referencia"),
                rs.getBoolean("activo"),
                rs.getTimestamp("created_at").toLocalDateTime()
        );
    }
}
