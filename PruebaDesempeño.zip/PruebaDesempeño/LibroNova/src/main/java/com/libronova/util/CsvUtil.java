package com.libronova.util;

import com.libronova.model.Libro;
import com.libronova.model.Socio;
import com.libronova.model.Usuario;
import com.libronova.model.Prestamo;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

/**
 * Clase utilitaria para exportar datos a archivos CSV.
 * Cada método genera un archivo en la carpeta raíz del proyecto.
 */
public class CsvUtil {

    private static final String OUTPUT_DIR = System.getProperty("user.dir") + "/exportaciones/";

    // ==========================
    // 📚 LIBROS
    // ==========================
    public static void exportarLibros(List<Libro> libros) {
        String archivo = OUTPUT_DIR + "libros_export.csv";
        try (FileWriter writer = new FileWriter(archivo)) {
            writer.append("ISBN;TÍTULO;AUTOR;CATEGORÍA;EJEMPLARES_TOTALES;EJEMPLARES_DISPONIBLES;PRECIO_REFERENCIA;ACTIVO;CREADO_EN\n");
            for (Libro l : libros) {
                writer.append(String.format("%s;%s;%s;%s;%d;%d;%.2f;%s;%s\n",
                        l.getIsbn(), l.getTitulo(), l.getAutor(), l.getCategoria(),
                        l.getEjemplaresTotales(), l.getEjemplaresDisponibles(),
                        l.getPrecioReferencia(), l.isActivo() ? "SI" : "NO", l.getCreatedAt()));
            }
            writer.flush();
            System.out.println("✅ Catálogo de libros exportado correctamente → " + archivo);
        } catch (IOException e) {
            System.err.println("❌ Error exportando libros: " + e.getMessage());
        }
    }

    // ==========================
    // 👥 SOCIOS
    // ==========================
    public static void exportarSocios(List<Socio> socios) {
        String archivo = OUTPUT_DIR + "socios_export.csv";
        try (FileWriter writer = new FileWriter(archivo)) {
            writer.append("ID;NOMBRE;EMAIL;TELÉFONO;ACTIVO;CREADO_EN\n");
            for (Socio s : socios) {
                writer.append(String.format("%s;%s;%s;%s;%s;%s\n",
                        s.getId(), s.getNombre(), s.getEmail(), s.getTelefono(),
                        s.isActivo() ? "SI" : "NO", s.getCreatedAt()));
            }
            writer.flush();
            System.out.println("✅ Lista de socios exportada correctamente → " + archivo);
        } catch (IOException e) {
            System.err.println("❌ Error exportando socios: " + e.getMessage());
        }
    }

    // ==========================
    // 🧑‍💼 USUARIOS
    // ==========================
    public static void exportarUsuarios(List<Usuario> usuarios) {
        String archivo = OUTPUT_DIR + "usuarios_export.csv";
        try (FileWriter writer = new FileWriter(archivo)) {
            writer.append("USERNAME;ROL;ACTIVO;CREADO_EN\n");
            for (Usuario u : usuarios) {
                writer.append(String.format("%s;%s;%s;%s\n",
                        u.getUsername(), u.getRol(), u.isActivo() ? "SI" : "NO", u.getCreatedAt()));
            }
            writer.flush();
            System.out.println("✅ Usuarios exportados correctamente → " + archivo);
        } catch (IOException e) {
            System.err.println("❌ Error exportando usuarios: " + e.getMessage());
        }
    }

    // ==========================
    // 📦 PRÉSTAMOS
    // ==========================
    public static void exportarPrestamos(List<Prestamo> prestamos) {
    String archivo = OUTPUT_DIR + "prestamos_export.csv";
    try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {
        pw.println("ID;Socio;Libro;FechaPrestamo;FechaDevolucion;Devuelto;Multa");
        for (Prestamo p : prestamos) {
            pw.printf("%d;%s;%s;%s;%s;%s;%.2f%n",
                    p.getId(),
                    p.getNombreSocio(),
                    p.getTituloLibro(),
                    p.getFechaPrestamo(),
                    p.getFechaDevolucion(),
                    p.isDevuelto() ? "Sí" : "No",
                    p.getMulta());
        }
    } catch (Exception e) {
        throw new RuntimeException("Error exportando préstamos: " + e.getMessage(), e);
    }
}

    public static void exportarPrestamosVencidos(List<Prestamo> prestamos) {
        String archivo = OUTPUT_DIR + "prestamos_vencidos.csv";
        try (PrintWriter pw = new PrintWriter(new FileWriter(archivo))) {
            pw.println("ID;Socio;Libro;FechaPrestamo;FechaDevolucion;Devuelto;Multa");
            for (Prestamo p : prestamos) {
                pw.printf("%d;%s;%s;%s;%s;%s;%.2f%n",
                        p.getId(),
                        p.getNombreSocio(),
                        p.getTituloLibro(),
                        p.getFechaPrestamo(),
                        p.getFechaDevolucion(),
                        p.isDevuelto() ? "Sí" : "No",
                        p.getMulta());
            }
        } catch (Exception e) {
            throw new RuntimeException("Error exportando vencidos: " + e.getMessage(), e);
        }
    }


    // ==========================
    // 🧰 MÉTODO GENERAL
    // ==========================
    public static void exportarTodo(List<Libro> libros, List<Socio> socios, List<Usuario> usuarios, List<Prestamo> prestamos) {
        exportarLibros(libros);
        exportarSocios(socios);
        exportarUsuarios(usuarios);
        exportarPrestamos(prestamos);
        System.out.println("✅ Todos los datos han sido exportados correctamente.");
    }
}
