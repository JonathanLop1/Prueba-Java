package com.libronova.controller;

import com.libronova.service.UsuarioService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;

public class LoginController {

    @FXML private TextField txtUsuario;
    @FXML private PasswordField txtPassword;

    private final UsuarioService usuarioService = new UsuarioService();

    @FXML
    private void iniciarSesion() {
        String username = txtUsuario.getText().trim();
        String password = txtPassword.getText().trim();

        if (username.isEmpty() || password.isEmpty()) {
            alert("Campos vacíos", "Por favor ingrese usuario y contraseña.", Alert.AlertType.WARNING);
            return;
        }

        if (usuarioService.autenticar(username, password)) {
            alert("Bienvenido", "Acceso concedido, cargando menú...", Alert.AlertType.INFORMATION);
            try {
                Stage stage = (Stage) txtUsuario.getScene().getWindow();
                Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/view/main.fxml")));
                stage.setScene(scene);
            } catch (IOException e) {
                alert("Error", "No se pudo cargar el menú principal.", Alert.AlertType.ERROR);
            }
        } else {
            alert("Acceso denegado", "Usuario o contraseña incorrectos.", Alert.AlertType.ERROR);
        }
    }

    private void alert(String t, String m, Alert.AlertType tp) {
        Alert a = new Alert(tp);
        a.setTitle(t);
        a.setHeaderText(null);
        a.setContentText(m);
        a.showAndWait();
    }
}
