package com.libronova.exception;

/**
 * Excepción para errores en acceso a datos (SQL, conexión, JDBC).
 * Se usa para desacoplar el detalle técnico del mensaje al usuario.
 */
public class DataAccessException extends RuntimeException {

    public DataAccessException(String message) {
        super(message);
    }

    public DataAccessException(String message, Throwable cause) {
        super(message, cause);
    }
}
