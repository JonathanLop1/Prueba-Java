package com.libronova.controller;

import com.libronova.model.Socio;
import com.libronova.service.SocioService;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.time.LocalDateTime;

public class SocioController {

    @FXML private TextField txtId;
    @FXML private TextField txtNombre;
    @FXML private TextField txtEmail;
    @FXML private TextField txtTelefono;

    @FXML private TableView<Socio> tablaSocios;
    @FXML private TableColumn<Socio, String> colId;
    @FXML private TableColumn<Socio, String> colNombre;
    @FXML private TableColumn<Socio, String> colEmail;
    @FXML private TableColumn<Socio, String> colTelefono;
    @FXML private TableColumn<Socio, Boolean> colActivo;
    @FXML private TableColumn<Socio, String> colCreatedAt;

    private final SocioService socioService = new SocioService();
    private final ObservableList<Socio> socios = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colEmail.setCellValueFactory(new PropertyValueFactory<>("email"));
        colTelefono.setCellValueFactory(new PropertyValueFactory<>("telefono"));
        colActivo.setCellValueFactory(new PropertyValueFactory<>("activo"));
        colCreatedAt.setCellValueFactory(new PropertyValueFactory<>("createdAt"));

        refrescarTabla();
    }

    // 🔹 Crear socio
    @FXML
    private void crearSocio() {
        try {
            if (txtId.getText().isBlank() || txtNombre.getText().isBlank()) {
                alert("Error", "El ID y el nombre son obligatorios.", Alert.AlertType.ERROR);
                return;
            }

            Socio s = new Socio(
                    txtId.getText().trim(),
                    txtNombre.getText().trim(),
                    txtEmail.getText().trim(),
                    txtTelefono.getText().trim(),
                    true,
                    LocalDateTime.now()
            );

            socioService.crearSocio(s);
            alert("Éxito", "Socio creado correctamente.", Alert.AlertType.INFORMATION);
            refrescarTabla();
            limpiarCampos();
        } catch (Exception e) {
            alert("Error", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // 🔹 Editar socio
    @FXML
    private void editarSocio() {
        Socio seleccionado = tablaSocios.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            alert("Error", "Seleccione un socio para editar.", Alert.AlertType.WARNING);
            return;
        }

        try {
            seleccionado.setNombre(txtNombre.getText().trim());
            seleccionado.setEmail(txtEmail.getText().trim());
            seleccionado.setTelefono(txtTelefono.getText().trim());
            socioService.actualizarSocio(seleccionado);
            alert("Actualizado", "Socio editado correctamente.", Alert.AlertType.INFORMATION);
            refrescarTabla();
            limpiarCampos();
        } catch (Exception e) {
            alert("Error", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // 🔹 Eliminar socio
    @FXML
    private void eliminarSocio() {
        Socio seleccionado = tablaSocios.getSelectionModel().getSelectedItem();
        if (seleccionado == null) {
            alert("Error", "Seleccione un socio para eliminar.", Alert.AlertType.WARNING);
            return;
        }

        try {
            socioService.eliminarSocio(seleccionado.getId());
            alert("Eliminado", "Socio eliminado correctamente.", Alert.AlertType.INFORMATION);
            refrescarTabla();
        } catch (Exception e) {
            alert("Error", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // 🔹 Exportar
    @FXML
    private void exportarSocios() {
        try {
            socioService.exportarSocios();
            alert("Éxito", "Socios exportados correctamente.", Alert.AlertType.INFORMATION);
        } catch (Exception e) {
            alert("Error", "No se pudo exportar: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    // 🔹 Regresar al menú
    @FXML
    private void regresarMenu() {
        try {
            Stage stage = (Stage) tablaSocios.getScene().getWindow();
            Scene scene = new Scene(FXMLLoader.load(getClass().getResource("/view/main.fxml")));
            stage.setScene(scene);
        } catch (IOException e) {
            alert("Error", "No se pudo regresar al menú: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void refrescarTabla() {
        socios.setAll(socioService.listarSocios());
        tablaSocios.setItems(socios);
    }

    private void limpiarCampos() {
        txtId.clear();
        txtNombre.clear();
        txtEmail.clear();
        txtTelefono.clear();
    }

    private void alert(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert a = new Alert(tipo);
        a.setTitle(titulo);
        a.setHeaderText(null);
        a.setContentText(mensaje);
        a.showAndWait();
    }
}
