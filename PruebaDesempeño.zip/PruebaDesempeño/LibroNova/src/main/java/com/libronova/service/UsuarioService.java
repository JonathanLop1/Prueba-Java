package com.libronova.service;

import com.libronova.dao.UsuarioDao;
import com.libronova.dao.impl.UsuarioDaoImpl;
import com.libronova.decorator.UsuarioDecorator;
import com.libronova.exception.BusinessException;
import com.libronova.model.Usuario;
import com.libronova.util.CsvUtil;
import com.libronova.util.LogConfig;

import java.util.List;
import java.util.logging.Logger;

public class UsuarioService {

    private final UsuarioDao usuarioDao;
    private final Logger logger = LogConfig.getLogger(UsuarioService.class);

    public UsuarioService() {
        // Se aplica el decorador sobre el DAO real
        this.usuarioDao = new UsuarioDecorator(new UsuarioDaoImpl());
    }

    // ==============================
    // CREAR USUARIO
    // ==============================
    public void crearUsuario(Usuario usuario) {
        logger.info("POST /usuarios - creando usuario " + usuario.getUsername());

        if (usuario.getUsername() == null || usuario.getUsername().isBlank()) {
            throw new BusinessException("El nombre de usuario no puede estar vacío.");
        }
        if (usuario.getPassword() == null || usuario.getPassword().isBlank()) {
            throw new BusinessException("La contraseña no puede estar vacía.");
        }
        if (buscarPorUsername(usuario.getUsername()) != null) {
            throw new BusinessException("Ya existe un usuario con ese nombre.");
        }

        usuarioDao.crear(usuario);
        logger.info("✅ Usuario creado correctamente: " + usuario.getUsername());
    }

    // ==============================
    // ACTUALIZAR
    // ==============================
    public void actualizarUsuario(Usuario usuario) {
        logger.info("PATCH /usuarios/" + usuario.getUsername());
        usuarioDao.actualizar(usuario);
    }

    // ==============================
    // ELIMINAR
    // ==============================
    public void eliminarUsuario(String username) {
        logger.info("DELETE /usuarios/" + username);
        usuarioDao.eliminar(username);
    }

    // ==============================
    // LISTAR
    // ==============================
    public List<Usuario> listarUsuarios() {
        logger.info("GET /usuarios");
        return usuarioDao.listar();
    }

    // ==============================
    // BUSCAR POR USERNAME
    // ==============================
    public Usuario buscarPorUsername(String username) {
        return usuarioDao.buscarPorUsername(username);
    }

    // ==============================
    // LOGIN / AUTENTICAR
    // ==============================
    public boolean autenticar(String username, String password) {
        logger.info("POST /login - autenticando usuario: " + username);

        Usuario u = usuarioDao.buscarPorUsername(username);
        if (u == null) {
            logger.warning("❌ Usuario no encontrado: " + username);
            return false;
        }
        if (!u.isActivo()) {
            logger.warning("⚠️ Usuario inactivo: " + username);
            throw new BusinessException("El usuario está inactivo.");
        }

        boolean ok = u.getPassword().equals(password);
        if (ok) {
            logger.info("✅ Autenticación exitosa de " + username);
        } else {
            logger.warning("❌ Contraseña incorrecta para " + username);
        }
        return ok;
    }

    // ==============================
    // EXPORTAR A CSV
    // ==============================
    public void exportarUsuarios() {
        logger.info("EXPORT /usuarios_export.csv");
        List<Usuario> lista = listarUsuarios();
        CsvUtil.exportarUsuarios(lista);
        logger.info("✅ Usuarios exportados correctamente.");
    }
}
