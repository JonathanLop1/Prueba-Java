package com.libronova.dao.impl;

import com.libronova.dao.SocioDao;
import com.libronova.model.Socio;
import com.libronova.util.DB;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementación JDBC del DAO de Socios.
 */
public class SocioDaoImpl implements SocioDao {

    @Override
    public void crear(Socio socio) {
        String sql = "INSERT INTO socios (id, nombre, email, telefono, activo, created_at) VALUES (?, ?, ?, ?, ?, NOW())";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, socio.getId());
            ps.setString(2, socio.getNombre());
            ps.setString(3, socio.getEmail());
            ps.setString(4, socio.getTelefono());
            ps.setBoolean(5, socio.isActivo());
            ps.executeUpdate();

        } catch (SQLIntegrityConstraintViolationException e) {
            throw new RuntimeException("⚠️ Ya existe un socio con el ID: " + socio.getId(), e);
        } catch (SQLException e) {
            throw new RuntimeException("❌ Error al crear socio: " + e.getMessage(), e);
        }
    }

    @Override
    public void actualizar(Socio socio) {
        String sql = "UPDATE socios SET nombre=?, email=?, telefono=?, activo=? WHERE id=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, socio.getNombre());
            ps.setString(2, socio.getEmail());
            ps.setString(3, socio.getTelefono());
            ps.setBoolean(4, socio.isActivo());
            ps.setString(5, socio.getId());
            int rows = ps.executeUpdate();

            if (rows == 0) {
                throw new SQLException("No se encontró el socio con ID: " + socio.getId());
            }

        } catch (SQLException e) {
            throw new RuntimeException("❌ Error al actualizar socio: " + e.getMessage(), e);
        }
    }

    @Override
    public void eliminar(String id) {
        String sql = "DELETE FROM socios WHERE id=?";
        try (Connection con = DB.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            int rows = ps.executeUpdate();

            if (rows == 0) {
                throw new SQLException("No existe el socio con ID: " + id);
            }

        } catch (SQLException e) {
            throw new RuntimeException("❌ Error al eliminar socio: " + e.getMessage(), e);
        }
    }

    @Override
    public List<Socio> listar() {
        List<Socio> lista = new ArrayList<>();
        String sql = "SELECT * FROM socios ORDER BY created_at DESC";

        try (Connection con = DB.getConnection();
             Statement st = con.createStatement();
             ResultSet rs = st.executeQuery(sql)) {

            while (rs.next()) {
                Timestamp ts = rs.getTimestamp("created_at");
                lista.add(new Socio(
                        rs.getString("id"),
                        rs.getString("nombre"),
                        rs.getString("email"),
                        rs.getString("telefono"),
                        rs.getBoolean("activo"),
                        ts != null ? ts.toLocalDateTime() : null
                ));
            }

        } catch (SQLException e) {
            throw new RuntimeException("❌ Error al listar socios: " + e.getMessage(), e);
        }
        return lista;
    }

    @Override
    public Socio buscarPorId(String idSocio) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
