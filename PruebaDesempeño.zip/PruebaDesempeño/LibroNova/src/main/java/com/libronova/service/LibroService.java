package com.libronova.service;

import com.libronova.dao.LibroDao;
import com.libronova.dao.impl.LibroDaoImpl;
import com.libronova.exception.ValidationException;
import com.libronova.model.Libro;
import com.libronova.util.CsvUtil;
import com.libronova.util.LogConfig;

import java.util.List;
import java.util.logging.Logger;

public class LibroService {

    private final LibroDao dao = new LibroDaoImpl();
    private final Logger logger = LogConfig.getLogger(LibroService.class);

    // 🔹 Crear libro
    public void agregarLibro(Libro libro) {
        if (dao.buscarPorIsbn(libro.getIsbn()) != null)
            throw new ValidationException("Ya existe un libro con ISBN " + libro.getIsbn());
        if (libro.getEjemplaresTotales() <= 0)
            throw new ValidationException("Debe haber al menos 1 ejemplar.");

        // Sincronizar disponibilidad inicial con el total
        libro.setEjemplaresDisponibles(libro.getEjemplaresTotales());

        dao.crear(libro);
        logger.info("📘 Libro agregado correctamente: " + libro.getTitulo());
    }

    // 🔹 Actualizar libro
    public void actualizarLibro(Libro libro) {
        Libro existente = dao.buscarPorIsbn(libro.getIsbn());
        if (existente == null)
            throw new ValidationException("El libro no existe.");

        // Calcular diferencia de ejemplares
        int diferencia = libro.getEjemplaresTotales() - existente.getEjemplaresTotales();

        // Si se agregaron ejemplares, sumarlos también a los disponibles
        if (diferencia > 0) {
            libro.setEjemplaresDisponibles(existente.getEjemplaresDisponibles() + diferencia);
        }
        // Si se redujo el total, ajustar disponibles para que no superen el nuevo total
        else if (diferencia < 0) {
            int nuevosDisponibles = Math.max(0, 
                Math.min(libro.getEjemplaresTotales(), existente.getEjemplaresDisponibles() + diferencia));
            libro.setEjemplaresDisponibles(nuevosDisponibles);
        } else {
            libro.setEjemplaresDisponibles(existente.getEjemplaresDisponibles());
        }

        // Validar coherencia
        if (libro.getEjemplaresDisponibles() > libro.getEjemplaresTotales()) {
            libro.setEjemplaresDisponibles(libro.getEjemplaresTotales());
        }

        dao.actualizar(libro);
        logger.info("✏️ Libro actualizado: " + libro.getTitulo() + " (" + libro.getIsbn() + ")");
    }

    // 🔹 Eliminar libro
    public void eliminarLibro(String isbn) {
        Libro l = dao.buscarPorIsbn(isbn);
        if (l == null) throw new ValidationException("El libro no existe.");
        dao.eliminar(isbn);
        logger.info("🗑️ Libro eliminado: " + isbn);
    }

    // 🔹 Listar todos los libros
    public List<Libro> listarLibros() {
        return dao.listar();
    }

    // 🔹 Filtrar libros
    public List<Libro> filtrar(String criterio) {
        return dao.filtrarPorAutorOCategoria(criterio);
    }

    // 🔹 Exportar catálogo a CSV
    public void exportarCatalogo() {
        CsvUtil.exportarLibros(listarLibros());
        logger.info("📤 Catálogo exportado correctamente.");
    }
}
