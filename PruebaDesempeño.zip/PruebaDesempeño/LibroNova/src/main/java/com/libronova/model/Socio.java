package com.libronova.model;

import java.time.LocalDateTime;

/**
 * Modelo de datos para la entidad Socio.
 * Representa a los clientes que pueden realizar préstamos.
 */
public class Socio {

    private String id;
    private String nombre;
    private String email;
    private String telefono;
    private boolean activo;
    private LocalDateTime createdAt;

    // =====================
    // 🔹 Constructores
    // =====================

    public Socio() {
    }

    public Socio(String id, String nombre, String email, String telefono, boolean activo) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.activo = activo;
        this.createdAt = LocalDateTime.now();
    }

    public Socio(String id, String nombre, String email, String telefono, boolean activo, LocalDateTime createdAt) {
        this.id = id;
        this.nombre = nombre;
        this.email = email;
        this.telefono = telefono;
        this.activo = activo;
        this.createdAt = createdAt;
    }

    // =====================
    // 🔹 Getters y Setters
    // =====================

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }

    public boolean isActivo() {
        return activo;
    }

    public void setActivo(boolean activo) {
        this.activo = activo;
    }

    public LocalDateTime getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(LocalDateTime createdAt) {
        this.createdAt = createdAt;
    }

    // =====================
    // 🔹 Métodos utilitarios
    // =====================

    @Override
    public String toString() {
        return String.format("%s - %s (%s)", id, nombre, activo ? "Activo" : "Inactivo");
    }

    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (!(obj instanceof Socio socio)) return false;
        return id != null && id.equals(socio.getId());
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}
