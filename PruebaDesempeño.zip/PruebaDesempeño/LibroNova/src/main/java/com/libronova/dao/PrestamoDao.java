package com.libronova.dao;

import com.libronova.model.Prestamo;
import java.util.List;

/**
 * Interfaz DAO para la entidad Prestamo.
 * Define las operaciones CRUD y consultas especializadas.
 */
public interface PrestamoDao {

    /**
     * Inserta un nuevo préstamo en la base de datos.
     * @param prestamo entidad con los datos del préstamo
     */
    void crear(Prestamo prestamo);

    /**
     * Actualiza los campos de un préstamo existente (por ejemplo al devolverlo).
     * @param prestamo entidad con los nuevos valores
     */
    void actualizar(Prestamo prestamo);

    /**
     * Lista todos los préstamos registrados (activos y devueltos).
     * Incluye los nombres de socios y títulos de libros mediante JOIN.
     * @return lista completa de préstamos
     */
    List<Prestamo> listar();

    /**
     * Lista únicamente los préstamos que están vencidos
     * (fecha_devolucion < fecha actual y devuelto = false).
     * @return lista de préstamos vencidos
     */
    List<Prestamo> listarVencidos();

    /**
     * Busca un préstamo activo (no devuelto) según socio y libro.
     * Esto se usa al devolver un libro.
     * @param idSocio ID del socio
     * @param isbn ISBN del libro
     * @return préstamo pendiente o null si no existe
     */
    Prestamo buscarPrestamoPendiente(String idSocio, String isbn);
}
