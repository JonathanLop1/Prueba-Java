package com.libronova.service;

import com.libronova.dao.SocioDao;
import com.libronova.dao.impl.SocioDaoImpl;
import com.libronova.model.Socio;
import com.libronova.util.CsvUtil;
import java.util.List;

public class SocioService {

    private final SocioDao dao = new SocioDaoImpl();

    public void crearSocio(Socio socio) {
        dao.crear(socio);
    }

    public void actualizarSocio(Socio socio) {
        dao.actualizar(socio);
    }

    public void eliminarSocio(String id) {
        dao.eliminar(id);
    }

    public List<Socio> listarSocios() {
        return dao.listar();
    }

    public void exportarSocios() {
        CsvUtil.exportarSocios(listarSocios());
    }
}
