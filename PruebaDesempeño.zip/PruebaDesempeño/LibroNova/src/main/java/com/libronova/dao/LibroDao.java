package com.libronova.dao;

import com.libronova.model.Libro;
import java.util.List;

public interface LibroDao {
    void crear(Libro libro);
    void actualizar(Libro libro);
    void eliminar(String isbn);
    Libro buscarPorIsbn(String isbn);
    List<Libro> listar();
    List<Libro> filtrarPorAutorOCategoria(String criterio);
}
