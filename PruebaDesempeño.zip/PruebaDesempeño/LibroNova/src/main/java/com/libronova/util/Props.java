package com.libronova.util;

import java.io.InputStream;
import java.util.Properties;

/**
 * Carga de configuración desde el archivo config.properties.
 * Ejemplo de parámetros:
 * db.url=jdbc:mysql://localhost:3306/libronova
 * db.user=root
 * db.password=1234
 * diasPrestamo=7
 * multaPorDia=1500
 */
public class Props {

    private static final Properties props = new Properties();

    static {
        try (InputStream input = Props.class.getResourceAsStream("/config.properties")) {
            if (input != null) {
                props.load(input);
            } else {
                System.err.println("⚠️ No se encontró el archivo config.properties en resources/");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static String get(String key) {
        return props.getProperty(key);
    }

    public static int getInt(String key) {
        return Integer.parseInt(props.getProperty(key));
    }

    public static double getDouble(String key) {
        return Double.parseDouble(props.getProperty(key));
    }
}
