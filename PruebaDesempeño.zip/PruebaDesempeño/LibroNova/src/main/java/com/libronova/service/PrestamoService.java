package com.libronova.service;

import com.libronova.dao.LibroDao;
import com.libronova.dao.PrestamoDao;
import com.libronova.dao.impl.LibroDaoImpl;
import com.libronova.dao.impl.PrestamoDaoImpl;
import com.libronova.exception.BusinessException;
import com.libronova.model.Libro;
import com.libronova.model.Prestamo;
import com.libronova.util.CsvUtil;
import com.libronova.util.DB;
import com.libronova.validation.Validators;

import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

public class PrestamoService {

    private final PrestamoDao prestamoDao = new PrestamoDaoImpl();
    private final LibroDao libroDao = new LibroDaoImpl();

    /**
     * Registra un nuevo préstamo con validaciones de negocio y transacción JDBC.
     */
    public void registrarPrestamo(Prestamo p) {
        try (Connection conn = DB.getConnection()) {
            conn.setAutoCommit(false);

            // Validaciones previas
            if (p.getIdSocio() == null || p.getIdSocio().isBlank())
                throw new BusinessException("Debe seleccionar un socio válido.");

            if (p.getIsbnLibro() == null || p.getIsbnLibro().isBlank())
                throw new BusinessException("Debe seleccionar un libro válido.");

            Validators.validarPrestamo(p.getIsbnLibro(), p.getIdSocio());

            Libro libro;
            try {
                libro = libroDao.buscarPorIsbn(p.getIsbnLibro());
            } catch (Exception e) {
                throw new BusinessException("El libro no existe en el catálogo.");
            }

            if (libro == null)
                throw new BusinessException("El libro no existe en el catálogo.");

            if (libro.getEjemplaresDisponibles() <= 0)
                throw new BusinessException("No hay ejemplares disponibles para préstamo.");

            // Registrar el préstamo
            prestamoDao.crear(p);

            // Reducir stock disponible
            libro.setEjemplaresDisponibles(libro.getEjemplaresDisponibles() - 1);
            libroDao.actualizar(libro);

            conn.commit();

        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            try { DB.getConnection().rollback(); } catch (SQLException ignored) {}
            throw new RuntimeException("Error al registrar préstamo: " + e.getMessage(), e);
        }
    }

    /**
     * Procesa la devolución de un libro con control de multas y transacción.
     */
    public void devolverLibro(String idSocio, String isbn) {
        try (Connection conn = DB.getConnection()) {
            conn.setAutoCommit(false);

            Prestamo prestamo = prestamoDao.buscarPrestamoPendiente(idSocio.trim(), isbn.trim());
            if (prestamo == null)
                throw new BusinessException("No existe un préstamo activo para ese socio y libro.");

            double multa = Validators.calcularMulta(LocalDate.now(), prestamo.getFechaDevolucion());
            prestamo.setDevuelto(true);
            prestamo.setMulta(multa);

            prestamoDao.actualizar(prestamo);

            Libro libro = libroDao.buscarPorIsbn(isbn);
            libro.setEjemplaresDisponibles(libro.getEjemplaresDisponibles() + 1);
            libroDao.actualizar(libro);

            conn.commit();

        } catch (BusinessException e) {
            throw e;
        } catch (Exception e) {
            try { DB.getConnection().rollback(); } catch (SQLException ignored) {}
            throw new RuntimeException("Error al devolver libro: " + e.getMessage(), e);
        }
    }

    public List<Prestamo> listarPrestamos() {
        return prestamoDao.listar();
    }

    public List<Prestamo> listarPrestamosVencidos() {
        return prestamoDao.listarVencidos();
    }

    public void exportarPrestamosCSV() {
        CsvUtil.exportarPrestamos(prestamoDao.listar());
    }

    public void exportarPrestamosVencidosCSV() {
        CsvUtil.exportarPrestamosVencidos(prestamoDao.listarVencidos());
    }
}
