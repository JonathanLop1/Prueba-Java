package com.libronova.validation;

import com.libronova.exception.BusinessException;
import com.libronova.service.LibroService;
import com.libronova.service.SocioService;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Clase utilitaria para validaciones de negocio.
 */
public class Validators {

    private static final LibroService libroService = new LibroService();
    private static final SocioService socioService = new SocioService();

    // ==============================
    // VALIDAR PRÉSTAMO
    // ==============================
    public static void validarPrestamo(String isbn, String idSocio) {
        var libro = libroService.listarLibros().stream()
                .filter(l -> l.getIsbn().equals(isbn))
                .findFirst()
                .orElseThrow(() -> new BusinessException("El libro no existe."));

        if (libro.getEjemplaresDisponibles() <= 0) {
            throw new BusinessException("No hay ejemplares disponibles.");
        }

        var socio = socioService.listarSocios().stream()
                .filter(s -> s.getId().equals(idSocio))
                .findFirst()
                .orElseThrow(() -> new BusinessException("El socio no existe."));

        if (!socio.isActivo()) {
            throw new BusinessException("El socio no está activo.");
        }
    }

    // ==============================
    // VALIDAR LIBRO NUEVO
    // ==============================
    public static void validarLibroNuevo(String isbn) {
        boolean existe = libroService.listarLibros().stream()
                .anyMatch(l -> l.getIsbn().equals(isbn));
        if (existe) throw new BusinessException("Ya existe un libro con ese ISBN.");
    }

    // ==============================
    // CALCULAR MULTA
    // ==============================
    public static double calcularMulta(LocalDate fechaActual, LocalDate fechaDevolucion) {
        long diasAtraso = ChronoUnit.DAYS.between(fechaDevolucion, fechaActual);
        return diasAtraso > 0 ? diasAtraso * 1500.0 : 0.0;
    }
}
