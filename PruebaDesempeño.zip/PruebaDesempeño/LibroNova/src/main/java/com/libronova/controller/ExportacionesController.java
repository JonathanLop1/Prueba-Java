package com.libronova.controller;

import com.libronova.service.LibroService;
import com.libronova.service.SocioService;
import com.libronova.service.PrestamoService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.stage.Stage;
import java.io.IOException;

public class ExportacionesController {

    private final LibroService libroService = new LibroService();
    private final SocioService socioService = new SocioService();
    private final PrestamoService prestamoService = new PrestamoService();

    @FXML
    private void exportarLibros() {
        libroService.exportarCatalogo();
        mostrar("Libros exportados correctamente.");
    }

    @FXML
    private void exportarSocios() {
        socioService.exportarSocios();
        mostrar("Socios exportados correctamente.");
    }

    @FXML
    private void exportarPrestamos() {
        prestamoService.exportarPrestamosCSV();
        mostrar("Préstamos exportados correctamente.");
    }

    @FXML
    private void exportarPrestamosVencidos() {
        prestamoService.exportarPrestamosVencidosCSV();
        mostrar("Préstamos vencidos exportados correctamente.");
    }

    @FXML
    private void volverAlMenu() throws IOException {
        cambiarVista("/view/main.fxml");
    }

    @FXML
    private void cerrarSesion() throws IOException {
        cambiarVista("/view/login.fxml");
    }

    private void mostrar(String m) {
        Alert a = new Alert(Alert.AlertType.INFORMATION);
        a.setTitle("Exportación");
        a.setHeaderText(null);
        a.setContentText(m);
        a.showAndWait();
    }

    private void cambiarVista(String fxml) throws IOException {
        Stage stage = (Stage) Stage.getWindows().stream().filter(w -> w.isShowing()).findFirst().orElseThrow();
        stage.setScene(new Scene(FXMLLoader.load(getClass().getResource(fxml))));
    }
}
